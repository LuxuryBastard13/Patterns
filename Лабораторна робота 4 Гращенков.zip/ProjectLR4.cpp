#include <iostream>
#include <string>
#include <vector>
#include <ctime>
using namespace std;

class MainHero
{
public:
	virtual void Fight() {}
};

class Mag : public MainHero
{
public:

	void Fight() override
	{
		cout << "\t\t\t\t\t\t\t ���";
	}
};

class SpecialForce : public MainHero
{
public:

	void Fight() override
	{
		cout << "\t\t\t\t\t\t\t������� ";
	}
};

class Gods : public MainHero
{
public:

	void Fight() override
	{
		cout << "\t\t\t\t\t\t\t����";
	}
};



class Creator
{
public:
	virtual MainHero* createMainHero() const = 0;

	void SomeOperation()
	{
		MainHero* mainhero = this->createMainHero();

		mainhero->Fight();
	}
};

class ConcreteMag : public Creator
{
public:

	MainHero* createMainHero() const override
	{
		return new Mag();
	}
};

class ConcreteSpecialForce : public Creator
{
	MainHero* createMainHero() const override
	{
		return new SpecialForce();
	}
};

class ConcreteGods : public Creator
{
	MainHero* createMainHero()const override
	{
		return new Gods();
	}
};

class Enemy
{
public:
	virtual void Fight() {}
};

class Diablo : public Enemy
{
public:

	void Fight() override
	{
		cout << "\t������" << endl;
	}
};

class Bull : public Enemy
{
public:

	void Fight() override
	{
		cout << "\t���" << endl;
	}
};

class Bear : public Enemy
{
public:

	void Fight() override
	{
		cout << "\t�������" << endl;
	}
};

class EnemyCreator
{
public:
	virtual Enemy* createEnemy() const = 0;

	void SomeOperation()
	{
		Enemy* enemy = this->createEnemy();

		enemy->Fight();
	}
};

class ConcreteDiablo : public EnemyCreator
{
public:

	Enemy* createEnemy() const override
	{
		return new Diablo();
	}
};

class ConcreteBull : public EnemyCreator
{
public:

	Enemy* createEnemy() const override
	{
		return new Bull();
	}
};

class ConcreteBear : public EnemyCreator
{
public:

	Enemy* createEnemy() const override
	{
		return new Bear();
	}
};


class MainHeroEquipment
{
public:

	vector<string> equipment_parts;

	void PrintEquipment()
	{
		cout << "(";

		for (int i = 0; i < equipment_parts.size(); i++)
		{
			if (equipment_parts[i] == equipment_parts.back())
			{
				cout << equipment_parts[i] << ")" << endl;
			}
			else
			{
				cout << equipment_parts[i] << ",";
			}
		}

		cout << endl << endl;
	}
};

class Builder
{
public:

	virtual ~Builder() {}
	virtual void buildGun() const = 0;
	virtual void buildColdWeapon() const = 0;
	virtual void buildMagic() const = 0;
};

class EquipmentBuilder : public Builder
{
	MainHeroEquipment* equipment;

public:

	EquipmentBuilder()
	{
		this->Reset();
	}

	~EquipmentBuilder()
	{
		delete equipment;
	}

	void Reset()
	{
		this->equipment = new MainHeroEquipment();
	}

	void buildGun()const override {
		this->equipment->equipment_parts.push_back("���������");
	}

	void buildColdWeapon()const override {
		this->equipment->equipment_parts.push_back("�������� ������");
	}

	void buildMagic()const override {
		this->equipment->equipment_parts.push_back("�����");
	}

	MainHeroEquipment* getEquipment()
	{
		MainHeroEquipment* result = this->equipment;
		this->Reset();

		return result;
	}
};

class Director
{
	Builder* builder;

public:

	void set_builder(Builder* builder)
	{
		this->builder = builder;
	}

	void BuildForEasyLvl()
	{
		this->builder->buildGun();
		this->builder->buildColdWeapon();
		this->builder->buildMagic();
		this->builder->buildArmor();
		this->builder->buildSupport();
	}

	void BuildForNormalLvl()
	{
		this->builder->buildGun();
		this->builder->buildColdWeapon();
		this->builder->buildMagic();
		this->builder->buildArmor();
	}

	void BuildForHardLvl()
	{
		this->builder->buildGun();
		this->builder->buildColdWeapon();
		this->builder->buildMagic();
	}
};

class Game
{
public:

	void playGame()
	{
		//����� �����
		int choise;
		cout << "�������� �����:" << endl << endl;
		cout << "��� - 1\n������� - 2\n���� - 3\n\n\n";
		cin >> choise;

		Creator* mainhero = new ConcreteMag();

		switch (choise)
		{
		case 1:
			mainhero = new ConcreteMag();
			break;

		case 2:
			mainhero = new ConcreteSpecialForce();
			break;

		case 3:
			mainhero = new ConcreteGods();
			break;

		default:
			cout << "�������� ����� �����!" << endl;
			break;
		}


		//����� ������ ���������
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		EquipmentBuilder* builder = new EquipmentBuilder();
		Director* direktor = new Director();
		direktor->set_builder(builder);
		MainHeroEquipment* equipment = new MainHeroEquipment();

		cout << "\n�������� ������� ���������:" << endl;

		cout << "������ - 1\n������� - 2\n������� - 3\n\n";
		cin >> choise;

		switch (choise)
		{
		case 1:
			direktor->BuildForEasyLvl();
			equipment = builder->getEquipment();
			break;

		case 2:
			direktor->BuildForNormalLvl();
			equipment = builder->getEquipment();
			break;

		case 3:
			direktor->BuildForHardLvl();
			equipment = builder->getEquipment();
			break;

		default:
			cout << "�������� ����� ������ ���������!\n";
			break;
		}

		//��������� �������� ����������
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
		choise = 1 + rand() % 4;

		EnemyCreator* enemy = new ConcreteDiablo();

		switch (choise)
		{
		case 1:
			enemy = new ConcreteDiablo();
			break;

		case 2:
			enemy = new ConcreteBull();
			break;

		case 3:
			enemy = new ConcreteBear();
			break;
		}

		//�����
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		cout << "\t\t\t\t\t\t\t����� ��������!" << endl;
		cout << "========================================================================================================================";

		mainhero->SomeOperation();
		cout << "\tVS";
		enemy->SomeOperation();

		cout << "\t\t\t";
		equipment->PrintEquipment();


		delete mainhero;
		delete enemy;
		delete equipment;
		delete builder;
		delete direktor;
	}
};

int main()
{
	setlocale(LC_ALL, "rus");
	srand(time(NULL));

	Game game;
	game.playGame();

	return 0;
}